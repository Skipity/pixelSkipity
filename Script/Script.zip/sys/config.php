<?php
// +------------------------------------------------------------------------+
// | @author Deen Doughouz (DoughouzForest)
// | @author_url 1: http://pixelphotoscript.com
// | @author_url 2: http://codecanyon.net/user/doughouzforest
// | @author_email: pixelphotoscript@gmail.com   
// +------------------------------------------------------------------------+
// | Pixel Photo Script
// | Copyright (c) 2018 pixelphoto. All rights reserved.
// +------------------------------------------------------------------------+
@header('Location: install');
exit();
?>