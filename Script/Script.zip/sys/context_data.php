<?php 

$imgtypes = array(
	'bmp',
	'gif',
	'jpeg',
	'png',
	'jpg'
);

$vidtypes = array(
	'mp4',
	'mov',
	'3gp',
	'webm'
);

//set_exception_handler(function($e){return;});